
let descriptors = [];
let variants = {};
let pairwiseMatrix = [];
let normalizedWeights = [];

// Add descriptor
function addDescriptor() {
  const descriptorInput = document.getElementById('descriptorInput').value;
  if (descriptorInput !== "") {
    descriptors.push(descriptorInput);
    document.getElementById('descriptorInput').value = '';
    updateDescriptorList();
    updateDescriptorSelect();
    generateCIBMatrix();
    updatePairwiseTable();
  }
}

// Update descriptor list
function updateDescriptorList() {
  const list = document.getElementById('descriptorList');
  list.innerHTML = '';
  descriptors.forEach((descriptor, index) => {
    list.innerHTML += `<li>${descriptor}</li>`;
  });
}

// Add variant for a selected descriptor
function addVariant() {
  const descriptor = document.getElementById('descriptorSelect').value;
  const variant = document.getElementById('variantInput').value;
  if (!variants[descriptor]) variants[descriptor] = [];
  if (variant !== "") {
    variants[descriptor].push(variant);
    document.getElementById('variantInput').value = '';
    updateVariantList(descriptor);
  }
}

// Update descriptor select dropdown
function updateDescriptorSelect() {
  const select = document.getElementById('descriptorSelect');
  select.innerHTML = '';
  descriptors.forEach(descriptor => {
    select.innerHTML += `<option value="${descriptor}">${descriptor}</option>`;
  });
}

// Update variant list for the selected descriptor
function updateVariantList(descriptor) {
  const list = document.getElementById('variantList');
  list.innerHTML = '';
  variants[descriptor].forEach((variant, index) => {
    list.innerHTML += `<li>${variant}</li>`;
  });
}

// Update pairwise comparison table
function updatePairwiseTable() {
  const table = document.getElementById('pairwiseTable');
  table.innerHTML = '';

  if (descriptors.length < 2) return;

  let header = '<tr><th>Descriptors</th>';
  descriptors.forEach(descriptor => header += `<th>${descriptor}</th>`);
  header += '</tr>';
  table.innerHTML += header;

  descriptors.forEach((rowDesc, rowIndex) => {
    let row = `<tr><td>${rowDesc}</td>`;
    descriptors.forEach((colDesc, colIndex) => {
      if (rowIndex === colIndex) {
        row += `<td>1</td>`;
      } else if (rowIndex < colIndex) {
        row += `<td><input type="number" id="p${rowIndex}-${colIndex}" min="1" max="9" value="1"></td>`;
      } else {
        row += `<td id="p${rowIndex}-${colIndex}"></td>`;
      }
    });
    row += '</tr>';
    table.innerHTML += row;
  });
}

// The rest of the script continues...

